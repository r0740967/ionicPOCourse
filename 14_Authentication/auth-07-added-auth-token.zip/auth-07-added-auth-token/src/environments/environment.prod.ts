export const environment = {
  production: true,
  googleMapsAPIKey: 'YOUR_GOOGLE_MAPS_API_KEY',
  firebaseAPIKey: 'YOUR_FIREBASE_API_KEY'
};
